# Store Submission & Review Guide — Nursery Media Downloader (v1.4.0)

Use the pre-written disclosures below when submitting **Nursery Media Downloader** to the **Chrome Web Store Developer Console**, **Microsoft Edge Partner Center**, or **Mozilla Add-ons (AMO)**.

---

## Single-Purpose Description
> Nursery Media Downloader has a single, clear purpose: allowing parents and guardians to bulk-download high-resolution photos and videos of their children from their authenticated Famly and Bright Horizons FamilyApp nursery feeds directly to their local computer with original capture dates preserved in EXIF metadata and filenames.

## Permission Justifications

| Permission | Store Review Justification |
| :--- | :--- |
| **`downloads`** | Saves high-resolution nursery photos and videos directly into the user's local `Downloads/Nursery_Photos` folder using `chrome.downloads.download`. |
| **`storage`** | Stores user preferences (destination subfolder name, filename pattern, and Save-As prompt preference) in `chrome.storage.sync` and tracks previously downloaded media URLs in `chrome.storage.local`. |
| **`activeTab`** | Allows the extension action popup to query media queue counts and trigger batch downloads or feed auto-scrolling on the currently active nursery tab. |
| **`host_permissions`** | Scoped strictly to Famly (`*.famly.co`, `*.famly.com`, `*.famly.dk`, `*.famly.net`), Bright Horizons (`*.brighthorizons.co.uk`, `*.brighthorizons.com`), and their media delivery CDNs (`*.cloudfront.net`, `*.amazonaws.com`) to detect feed media and inject original capture dates into JPEG EXIF headers prior to saving. |

## Mozilla Firefox AMO Compliance Notes
* **Gecko Add-on ID:** `nursery-media-downloader@robinfowler.addon`
* **Data Collection Disclosure:** `browser_specific_settings.gecko.data_collection_permissions.required = ["none"]`
* **DOM Safety:** All in-page UI elements are constructed via `document.createElement` (zero `innerHTML` assignments) to pass `addons-linter` with zero warnings.
