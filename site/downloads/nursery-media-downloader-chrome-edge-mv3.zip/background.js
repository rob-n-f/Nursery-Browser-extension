// Background Service Worker for Nursery Media Downloader v1.4.0 (Manifest V3)
let activeDownloads = new Map();

chrome.runtime.onInstalled.addListener(() => {
  console.log('[Nursery Media Downloader] Extension v1.4.0 installed and ready.');
  chrome.storage.sync.get(['downloadFolder', 'namingPattern'], (res) => {
    if (!res.downloadFolder) {
      chrome.storage.sync.set({
        downloadFolder: 'Nursery_Photos',
        namingPattern: '{date}_media_{index}'
      });
    }
  });
});

// Helper: Formats date to EXIF standard (YYYY:MM:DD HH:MM:SS)
// Extracts exact hour from /archive/YYYY/MM/DD/HH/ path when present
function formatExifDate(dateStr, url) {
  const archiveMatch = (url || '').match(new RegExp('/archive/(\\d{4})/(\\d{2})/(\\d{2})(?:/(\\d{2}))?'));
  if (archiveMatch) {
    const hh = archiveMatch[4] && Number(archiveMatch[4]) <= 23 ? archiveMatch[4] : '12';
    return archiveMatch[1] + ':' + archiveMatch[2] + ':' + archiveMatch[3] + ' ' + hh + ':00:00';
  }
  const match = (dateStr || '').match(new RegExp('(\\d{4})[-/.](\\d{2})[-/.](\\d{2})'));
  if (match) {
    return match[1] + ':' + match[2] + ':' + match[3] + ' 12:00:00';
  }
  const now = new Date();
  const y = now.getFullYear();
  const m = String(now.getMonth() + 1).padStart(2, '0');
  const d = String(now.getDate()).padStart(2, '0');
  return y + ':' + m + ':' + d + ' 12:00:00';
}

// Helper: Injects standard APP1 EXIF segment (DateTimeOriginal, DateTimeDigitized, DateTime)
function injectExifIntoJpeg(buffer, dateStr, url) {
  const bytes = new Uint8Array(buffer);
  if (bytes.length < 4 || bytes[0] !== 0xff || bytes[1] !== 0xd8) {
    return buffer; // Not a JPEG
  }

  const exifDate = formatExifDate(dateStr, url);
  const dateBytes = new TextEncoder().encode(exifDate + '\0');

  // Build TIFF payload (88 bytes, Little Endian)
  const tiff = new Uint8Array(88);
  const view = new DataView(tiff.buffer);

  // TIFF Header
  view.setUint16(0, 0x4949, true); // "II"
  view.setUint16(2, 0x002a, true); // 42
  view.setUint32(4, 8, true);      // Offset to IFD0 = 8

  // IFD0 (2 directory entries)
  view.setUint16(8, 2, true);
  // Tag 0x0132 (DateTime)
  view.setUint16(10, 0x0132, true);
  view.setUint16(12, 2, true);
  view.setUint32(14, 20, true);
  view.setUint32(18, 68, true);
  // Tag 0x8769 (ExifOffset)
  view.setUint16(22, 0x8769, true);
  view.setUint16(24, 4, true);
  view.setUint32(26, 1, true);
  view.setUint32(30, 38, true);
  view.setUint32(34, 0, true);

  // Exif SubIFD (2 directory entries)
  view.setUint16(38, 2, true);
  // Tag 0x9003 (DateTimeOriginal)
  view.setUint16(40, 0x9003, true);
  view.setUint16(42, 2, true);
  view.setUint32(44, 20, true);
  view.setUint32(48, 68, true);
  // Tag 0x9004 (DateTimeDigitized)
  view.setUint16(52, 0x9004, true);
  view.setUint16(54, 2, true);
  view.setUint32(56, 20, true);
  view.setUint32(60, 68, true);
  view.setUint32(64, 0, true);

  // Write Date String
  tiff.set(dateBytes, 68);

  // Complete APP1 Segment (98 bytes)
  const app1 = new Uint8Array(2 + 96);
  app1[0] = 0xff;
  app1[1] = 0xe1;
  app1[2] = 0x00;
  app1[3] = 0x60; // 96 bytes length
  app1.set([0x45, 0x78, 0x69, 0x66, 0x00, 0x00], 4); // "Exif\0\0"
  app1.set(tiff, 10);

  // Replace or insert APP1 segment after SOI
  let insertPos = 2;
  let skipLen = 0;
  let pos = 2;
  while (pos < bytes.length - 4) {
    if (bytes[pos] === 0xff) {
      const marker = bytes[pos + 1];
      if (marker === 0xd9 || marker === 0xda) break;
      const segLen = (bytes[pos + 2] << 8) | bytes[pos + 3];
      if (marker === 0xe1) {
        insertPos = pos;
        skipLen = segLen + 2;
        break;
      } else if (marker === 0xe0) {
        insertPos = pos + segLen + 2;
      }
      pos += segLen + 2;
    } else {
      break;
    }
  }

  const before = bytes.slice(0, insertPos);
  const after = bytes.slice(insertPos + skipLen);
  const combined = new Uint8Array(before.length + app1.length + after.length);
  combined.set(before, 0);
  combined.set(app1, before.length);
  combined.set(after, before.length + app1.length);

  return combined.buffer;
}

// Convert ArrayBuffer to Data URL (used for JPEG EXIF injection in MV3 service workers)
function bufferToDataUrl(buffer, mimeType) {
  const bytes = new Uint8Array(buffer);
  let binary = '';
  const len = bytes.byteLength;
  for (let i = 0; i < len; i += 8192) {
    const chunk = bytes.subarray(i, Math.min(i + 8192, len));
    binary += String.fromCharCode.apply(null, chunk);
  }
  return 'data:' + mimeType + ';base64,' + btoa(binary);
}

// Handle messages from content script or popup
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'OPEN_OPTIONS') {
    chrome.runtime.openOptionsPage();
    sendResponse({ status: 'opened' });
    return true;
  }

  if (message.action === 'DOWNLOAD_ITEMS') {
    handleBatchDownload(message.items, sender.tab?.id);
    sendResponse({ status: 'started', count: message.items.length });
    return true;
  }

  if (message.action === 'GET_DOWNLOAD_STATUS') {
    sendResponse({ activeDownloads: Array.from(activeDownloads.values()) });
    return true;
  }

  if (message.action === 'MEDIA_DISCOVERED') {
    if (sender.tab?.id) {
      chrome.tabs.sendMessage(sender.tab.id, {
        action: 'AGGREGATE_MEDIA',
        items: message.items
      }).catch(() => {});
    }
    sendResponse({ received: true });
    return true;
  }
});

async function handleBatchDownload(items, tabId) {
  const settings = await chrome.storage.sync.get({
    downloadFolder: 'Nursery_Photos',
    namingPattern: '{date}_media_{index}',
    promptSaveAs: false
  });

  const total = items.length;
  let completed = 0;
  let failed = 0;

  for (let i = 0; i < items.length; i++) {
    const item = items[i];
    const isVideo = Boolean(item.url.includes('.mp4') || item.url.includes('.mov') || item.url.includes('video') || item.isVideo);
    const ext = isVideo ? '.mp4' : '.jpg';
    const indexStr = String(i + 1).padStart(3, '0');
    const mediaTypeToken = isVideo ? 'video' : 'photo';

    // Sanitize filename tokens
    let baseName = (settings.namingPattern || '{date}_media_{index}')
      .replace('{date}', item.date || 'undated')
      .replace('{index}', indexStr)
      .replace('{type}', mediaTypeToken)
      .replace(/[^a-zA-Z0-9_\-.]/g, '_');

    let folderPrefix = '';
    if (settings.downloadFolder && typeof settings.downloadFolder === 'string') {
      const trimmed = settings.downloadFolder.trim().replace(/^[/\\]+|[/\\]+$/g, '');
      if (trimmed.length > 0) {
        folderPrefix = trimmed + '/';
      }
    }
    const filename = folderPrefix + baseName + ext;
    const shouldPrompt = Boolean(settings.promptSaveAs && i === 0);

    try {
      await downloadItem(item, filename, isVideo, shouldPrompt);
      completed++;
    } catch (err) {
      console.error('[Nursery Media Downloader] Download failed for:', item.url, err);
      failed++;
    }

    // Notify tab of progress
    if (tabId) {
      chrome.tabs.sendMessage(tabId, {
        action: 'DOWNLOAD_PROGRESS',
        progress: { completed, failed, total, currentUrl: item.url }
      }).catch(() => {});
    }

    // Rate-limit to prevent browser download throttling
    await new Promise((r) => setTimeout(r, 350));
  }

  if (tabId) {
    chrome.tabs.sendMessage(tabId, {
      action: 'DOWNLOAD_COMPLETE',
      result: { completed, failed, total }
    }).catch(() => {});
  }
}

async function downloadItem(item, filename, isVideo, promptSaveAs = false) {
  let downloadUrl = item.url;

  // Only buffer & inject EXIF metadata for photos (!isVideo).
  // Videos stream directly via native browser download manager to avoid MV3 data-URL memory limits.
  if (!isVideo) {
    try {
      const res = await fetch(item.url);
      if (res.ok) {
        const buffer = await res.arrayBuffer();
        const finalBuffer = injectExifIntoJpeg(buffer, item.date, item.url);
        const mimeType = 'image/jpeg';
        if (typeof URL !== 'undefined' && typeof URL.createObjectURL === 'function') {
          const blob = new Blob([finalBuffer], { type: mimeType });
          downloadUrl = URL.createObjectURL(blob);
        } else {
          downloadUrl = bufferToDataUrl(finalBuffer, mimeType);
        }
      }
    } catch (fetchErr) {
      console.warn('[Nursery Media Downloader] Direct URL fallback (EXIF pre-process bypassed):', fetchErr);
      downloadUrl = item.url;
    }
  }

  return new Promise((resolve, reject) => {
    chrome.downloads.download({
      url: downloadUrl,
      filename: filename,
      conflictAction: 'uniquify',
      saveAs: Boolean(promptSaveAs)
    }, (downloadId) => {
      if (downloadUrl.startsWith('blob:')) {
        setTimeout(() => {
          try { URL.revokeObjectURL(downloadUrl); } catch (e) {}
        }, 60000);
      }
      if (chrome.runtime.lastError) {
        return reject(chrome.runtime.lastError);
      }
      if (!downloadId) {
        return reject(new Error('Download failed to start'));
      }
      activeDownloads.set(downloadId, { url: item.url, filename, status: 'in_progress' });
      resolve(downloadId);
    });
  });
}

// Track download completion state
chrome.downloads.onChanged.addListener((delta) => {
  if (delta.state && delta.state.current === 'complete') {
    activeDownloads.delete(delta.id);
  } else if (delta.error) {
    activeDownloads.delete(delta.id);
  }
});
