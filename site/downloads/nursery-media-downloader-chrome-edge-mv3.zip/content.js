// Content script for Famly / Bright Horizons FamilyApp Media Downloader
(function() {
  'use strict';

  // Only run in top window - completely eliminates execution inside tracking and embedded iframes
  if (typeof window !== 'undefined' && window.top !== window) {
    return;
  }

  // State
  const mediaQueue = new Map(); // key: canonicalKey, value: { key, url, date, type, isVideo, discoveredAt }
  const downloadedUrls = new Set();
  let isDownloading = false;
  let autoScrollInterval = null;
  let isPanelMinimized = false;
  let scanCycles = 0;
  let harvestDebounceTimer = null;
  let lastQueuedCount = -1;
  let lastSavedCount = -1;
  let lastDownloadingState = null;
  let cachedScrollContainer = null;

  // Restore downloaded set from extension storage (safe callback check)
  try {
    chrome.storage.local.get(['downloadedHistory'], (res) => {
      if (res && Array.isArray(res.downloadedHistory)) {
        res.downloadedHistory.forEach((u) => downloadedUrls.add(getMediaKey(u)));
      }
      updateUI();
    });
  } catch (e) {}

  /**
   * Generates a stable canonical key from a media URL.
   * Normalizes to the immutable /archive/... path when present so portrait/landscape
   * variants and daily rotating HMAC signatures / expiring tokens share one key.
   */
  function getMediaKey(url) {
    if (!url) return '';
    try {
      const parsed = new URL(url, window.location.href);
      const archiveIdx = parsed.pathname.indexOf('/archive/');
      if (archiveIdx !== -1) {
        return parsed.origin + parsed.pathname.substring(archiveIdx);
      }
      return parsed.origin + parsed.pathname;
    } catch (e) {
      return url;
    }
  }

  /**
   * Parses srcset attribute strings into individual clean URL candidates
   */
  function parseSrcsetUrls(srcset) {
    if (!srcset || typeof srcset !== 'string') return [];
    const results = [];
    const candidates = srcset.split(',').map((s) => s.trim()).filter(Boolean);
    for (const cand of candidates) {
      const spaceIdx = cand.lastIndexOf(' ');
      let candUrl = cand;
      if (spaceIdx > 0) {
        candUrl = cand.substring(0, spaceIdx).trim();
      }
      if (candUrl) results.push(candUrl);
    }
    return results;
  }

  /**
   * Transforms Famly & Bright Horizons CDN thumbnail/cropped URLs into full-res master images
   * Preserves portrait (1080x1920) vs landscape (1920x1080) orientation, /archive/ path structure,
   * valid HMAC tokens, and query credentials.
   */
  function toFullRes(url) {
    if (!url) return null;
    try {
      const parsed = new URL(url, window.location.href);

      // Remove downscaling / cropping query parameters if present
      const paramsToDelete = ['crop', 'width', 'height', 'w', 'h', 'fit', 'max-w', 'max-h'];
      for (const p of paramsToDelete) {
        if (parsed.searchParams.has(p)) {
          parsed.searchParams.delete(p);
        }
      }

      // If already at full 1080p (landscape 1920x1080 or portrait 1080x1920), return cleaned URL
      if (parsed.pathname.includes('/1920x1080/') || parsed.pathname.includes('/1080x1920/')) {
        return parsed.toString();
      }

      // Famly & Bright Horizons image path structure:
      // /image/{hash}/{dimension}/archive/...
      const parts = parsed.pathname.split('/');
      for (let i = 0; i < parts.length; i++) {
        if (parts[i] === 'image' && parts[i + 2]) {
          const dimSeg = parts[i + 2];
          const dimMatch = dimSeg.match(/^([0-9]+)x([0-9]+)$/i);
          if (dimMatch) {
            const w = parseInt(dimMatch[1], 10);
            const h = parseInt(dimMatch[2], 10);
            // Preserve portrait (e.g. 520x1040 -> 1080x1920) vs landscape (e.g. 1040x520 -> 1920x1080)
            parts[i + 2] = w < h ? '1080x1920' : '1920x1080';
            break;
          } else if (/^(thumbnail|scaled|small|medium|thumb)$/i.test(dimSeg)) {
            parts[i + 2] = '1920x1080';
            break;
          } else if (dimSeg === 'archive') {
            // Dimension wasn't in path: insert 1920x1080 before archive
            parts.splice(i + 2, 0, '1920x1080');
            break;
          }
        }
      }
      parsed.pathname = parts.join('/');

      return parsed.toString();
    } catch (e) {
      return url;
    }
  }

  /**
   * Extracts date string (YYYY-MM-DD) from CDN archive/S3 path or nearby DOM elements
   */
  function extractDateFromMedia(url, element) {
    // 1. From URL pathname: matches both /archive/YYYY/MM/DD/ (photos) and /YYYY/MM/DD/HH/{uuid}/ (S3 videos)
    try {
      const parsedPath = new URL(url, window.location.href).pathname;
      const pathMatch = parsedPath.match(new RegExp('/((?:19|20)[0-9]{2})/(0[1-9]|1[0-2])/(0[1-9]|[12][0-9]|3[01])/', 'i'));
      if (pathMatch) {
        return pathMatch[1] + '-' + pathMatch[2] + '-' + pathMatch[3];
      }
    } catch (e) {}

    const archiveMatch = (url || '').match(new RegExp('/((?:19|20)[0-9]{2})/(0[1-9]|1[0-2])/(0[1-9]|[12][0-9]|3[01])/', 'i'));
    if (archiveMatch) {
      return archiveMatch[1] + '-' + archiveMatch[2] + '-' + archiveMatch[3];
    }

    // 2. Fallback: Search parent story / activity card for timestamp element or post link (e.g. "22 Apr 2024")
    if (element) {
      try {
        const card = element.closest
          ? element.closest('.story, article, [class*="activity"], [class*="feed-item"], [class*="post"], [class*="card"]')
          : null;
        if (card) {
          const timeEl = card.querySelector('time, a[href*="/post/"], [class*="timestamp"], [class*="date"], [datetime]');
          if (timeEl) {
            const dt = timeEl.getAttribute('datetime') || timeEl.textContent;
            if (dt) {
              const parsed = new Date(dt.trim() + ' 12:00:00');
              if (!isNaN(parsed.getTime())) {
                const y = parsed.getFullYear();
                const m = String(parsed.getMonth() + 1).padStart(2, '0');
                const d = String(parsed.getDate()).padStart(2, '0');
                return y + '-' + m + '-' + d;
              }
            }
          }
        }
      } catch (e) {}
    }

    // 3. Fallback: Match ISO date pattern in URL
    const isoMatch = (url || '').match(/(202[0-9])[-_/](0[1-9]|1[0-2])[-_/](0[1-9]|[12][0-9]|3[01])/);
    if (isoMatch) {
      return isoMatch[1] + '-' + isoMatch[2] + '-' + isoMatch[3];
    }

    return 'undated';
  }

  /**
   * Determines if a candidate URL and element represent real nursery media
   */
  function isNurseryMedia(url, el) {
    if (!url || typeof url !== 'string') return false;
    const lower = url.toLowerCase();

    // Ignore extension's own UI elements
    if (el) {
      try {
        if (el.closest && el.closest('#famly-downloader-panel')) return false;
      } catch (e) {}
    }

    // Ignore tracking pixels, SVG icons, and S3 video poster thumbnails (thumb-00001.jpg)
    if (
      lower.startsWith('data:image/svg') ||
      lower.startsWith('data:image/gif') ||
      lower.includes('/icons/') ||
      lower.includes('logo.svg') ||
      new RegExp('/thumb-[0-9]+\\.jpe?g(\\?|$)', 'i').test(lower)
    ) {
      return false;
    }

    // Primary matches on CDN URLs
    if (
      lower.includes('/archive/') ||
      lower.includes('/1920x1080/') ||
      lower.includes('/1080x1920/') ||
      lower.includes('/1040x520/') ||
      lower.includes('/520x1040/') ||
      lower.includes('/image/') ||
      lower.includes('/images/') ||
      lower.includes('img.familyapp') ||
      lower.includes('brighthorizons') ||
      lower.includes('famly') ||
      lower.includes('cloudfront.net') ||
      lower.includes('amazonaws.com') ||
      lower.includes('googleapis.com')
    ) {
      // Check if avatar / profile thumbnail (e.g. ?crop=face, /100x100/, /500x500/, comment form avatar, or child-profile-header)
      const isAvatar =
        lower.includes('/avatar/') ||
        lower.includes('avatar-') ||
        lower.includes('crop=face') ||
        lower.includes('/100x100/') ||
        lower.includes('/500x500/') ||
        lower.includes('empty-profile') ||
        lower.includes('profile-image') ||
        Boolean(
          el && (
            (el.className && typeof el.className === 'string' && el.className.toLowerCase().includes('avatar')) ||
            (el.closest && el.closest('#commentForm, .child-profile-header, .profile-header-wrapper, nav, header'))
          )
        );

      if (isAvatar) return false;
      if (lower.includes('/archive/')) return true;

      return (
        /\.(jpe?g|png|webp|avif|mp4|mov)(\?|$)/i.test(lower) ||
        lower.includes('/image/') ||
        lower.includes('/images/')
      );
    }

    // Fallback: If inside an article / post card on page
    if (el) {
      try {
        const inPost = el.closest && el.closest('article, .story, .postImages, [class*="post"], [class*="card"], [class*="feed"], [class*="activity"]');
        if (inPost && /\.(jpe?g|png|webp|avif|mp4)(\?|$)/i.test(lower)) {
          return true;
        }
      } catch (e) {}
    }

    return false;
  }

  /**
   * Fast node inspection: extracts media candidates from a node
   * Operates strictly on attributes without invoking getComputedStyle
   */
  function extractMediaFromNode(node) {
    if (!node || node.nodeType !== 1) return [];
    const found = [];

    // 1. <img> element
    if (node.tagName === 'IMG') {
      const srcAttrs = [
        'srcset', 'src', 'currentSrc',
        'data-src', 'data-srcset', 'data-original', 'data-url',
        'data-image', 'data-full', 'data-hires', 'data-hi-res',
        'data-large', 'data-media', 'data-asset'
      ];
      for (let i = 0; i < srcAttrs.length; i++) {
        const attr = srcAttrs[i];
        let val = '';
        if (attr === 'currentSrc' && node.currentSrc) val = node.currentSrc;
        else if (attr === 'srcset' && (node.getAttribute('srcset') || node.srcset)) val = node.getAttribute('srcset') || node.srcset;
        else if (node.getAttribute && node.getAttribute(attr)) val = node.getAttribute(attr);

        if (val) {
          if (attr.includes('srcset')) {
            const urls = parseSrcsetUrls(val);
            for (let k = 0; k < urls.length; k++) {
              found.push({ url: urls[k], el: node, type: 'image' });
            }
          } else {
            found.push({ url: val, el: node, type: 'image' });
          }
        }
      }
    }

    // 2. <source> element inside <picture> or <video>
    else if (node.tagName === 'SOURCE') {
      const srcset = node.getAttribute('srcset') || node.srcset;
      if (srcset) {
        const urls = parseSrcsetUrls(srcset);
        for (let k = 0; k < urls.length; k++) {
          found.push({ url: urls[k], el: node, type: 'image' });
        }
      }
      const src = node.getAttribute('src') || node.src;
      if (src) {
        const isVid = Boolean(
          (node.type && node.type.toLowerCase().includes('video')) ||
          (node.parentElement && node.parentElement.tagName === 'VIDEO') ||
          /\.(mp4|mov|webm)(\?|$)/i.test(src)
        );
        found.push({ url: src, el: node, type: isVid ? 'video' : 'image' });
      }
    }

    // 3. <video> element (including preload="none" videos with child <source> nodes)
    else if (node.tagName === 'VIDEO') {
      const src = node.currentSrc || node.src || (node.getAttribute && (node.getAttribute('src') || node.getAttribute('data-src')));
      if (src) found.push({ url: src, el: node, type: 'video' });
      if (node.querySelectorAll) {
        const sources = node.querySelectorAll('source');
        for (let s = 0; s < sources.length; s++) {
          const sUrl = sources[s].getAttribute('src') || sources[s].src;
          if (sUrl) found.push({ url: sUrl, el: node, type: 'video' });
        }
      }
    }

    // 4. Background images in style attribute (zero getComputedStyle overhead)
    else if (node.hasAttribute && node.hasAttribute('style')) {
      const styleAttr = node.getAttribute('style') || '';
      if (styleAttr.includes('url(')) {
        const matches = styleAttr.matchAll(/url\(['"]?([^'"\)\s]+)['"]?\)/gi);
        for (const m of matches) {
          if (m[1]) found.push({ url: m[1], el: node, type: 'image' });
        }
      }
    }

    // 5. <a> links pointing directly to photos
    else if (node.tagName === 'A') {
      const href = (node.getAttribute && node.getAttribute('href')) || node.href;
      if (href && (
        href.includes('/image/') ||
        href.includes('/archive/') ||
        /\.(jpe?g|png|webp|avif|mp4)(\?|$)/i.test(href)
      )) {
        found.push({ url: href, el: node, type: href.includes('.mp4') ? 'video' : 'image' });
      }
    }

    return found;
  }

  /**
   * Fast, targeted media harvester
   * Uses native querySelectorAll for actual media nodes instead of traversing full DOM
   */
  function harvestMedia() {
    let addedCount = 0;

    const selector = 'img, picture source, video, video source, a[href*="/image/"], a[href*="/archive/"], a[href*=".jpg"], a[href*=".jpeg"], a[href*=".png"], a[href*=".webp"], a[href*=".mp4"], [style*="url("]';
    const elements = document.querySelectorAll(selector);

    for (let i = 0; i < elements.length; i++) {
      const el = elements[i];
      const items = extractMediaFromNode(el);
      for (let j = 0; j < items.length; j++) {
        const raw = items[j];
        if (!raw.url) continue;

        if (isNurseryMedia(raw.url, raw.el)) {
          const highRes = raw.type === 'video' ? raw.url : toFullRes(raw.url);
          if (highRes) {
            const key = getMediaKey(highRes);
            if (!mediaQueue.has(key)) {
              const date = extractDateFromMedia(highRes, raw.el);
              mediaQueue.set(key, {
                key: key,
                url: highRes,
                date: date,
                type: raw.type || 'image',
                isVideo: raw.type === 'video' || highRes.includes('.mp4'),
                discoveredAt: Date.now()
              });
              addedCount++;
            } else {
              // Always refresh with the latest signed URL (handles rotating S3 X-Amz-Expires & CDN expires)
              const existing = mediaQueue.get(key);
              if (/expires|X-Amz-Signature/i.test(highRes)) {
                existing.url = highRes;
              }
            }
          }
        }
      }
    }

    if (addedCount > 0) {
      updateUI();
    }
    return addedCount;
  }

  /**
   * Schedules a debounced media harvest pass
   */
  function scheduleHarvest(delay) {
    const ms = typeof delay === 'number' ? delay : 400;
    if (harvestDebounceTimer) return;
    harvestDebounceTimer = setTimeout(() => {
      harvestDebounceTimer = null;
      harvestMedia();
    }, ms);
  }

  /**
   * Starts batch download via background service worker
   */
  function startDownload() {
    if (isDownloading || mediaQueue.size === 0) return;
    isDownloading = true;
    updateUI();

    const items = Array.from(mediaQueue.values());
    chrome.runtime.sendMessage({
      action: 'DOWNLOAD_ITEMS',
      items: items
    }, (response) => {
      console.log('[Nursery Downloader] Batch download initiated:', response);
    });
  }

  /**
   * Clean single-click trigger for React 18 & Material-UI (MuiButtonBase) buttons in Chrome & Firefox.
   * Dispatches pointer/mouse press sequence followed by a single native click so onClick fires once.
   */
  function triggerClick(el) {
    if (!el) return false;

    // 1. Bring button into view
    try {
      el.scrollIntoView({ behavior: 'instant', block: 'center' });
    } catch (e) {
      try { el.scrollIntoView(true); } catch (e2) {}
    }

    // 2. Set focus
    try { el.focus(); } catch (e) {}

    // 3. Dispatch pointer & mouse press/release sequence (triggers MuiTouchRipple without duplicate click events)
    try {
      if (typeof PointerEvent !== 'undefined') {
        el.dispatchEvent(new PointerEvent('pointerdown', { bubbles: true, cancelable: true, composed: true, view: window, isPrimary: true, pointerType: 'mouse', button: 0, buttons: 1 }));
      }
      el.dispatchEvent(new MouseEvent('mousedown', { bubbles: true, cancelable: true, composed: true, view: window, detail: 1, button: 0, buttons: 1 }));
      if (typeof PointerEvent !== 'undefined') {
        el.dispatchEvent(new PointerEvent('pointerup', { bubbles: true, cancelable: true, composed: true, view: window, isPrimary: true, pointerType: 'mouse', button: 0, buttons: 0 }));
      }
      el.dispatchEvent(new MouseEvent('mouseup', { bubbles: true, cancelable: true, composed: true, view: window, detail: 1, button: 0, buttons: 0 }));
    } catch (e) {}

    // 4. Fire a single click event (prefer un-sandboxed wrappedJSObject in Firefox if present, else standard el.click())
    let clicked = false;
    try {
      if (el.wrappedJSObject && typeof el.wrappedJSObject.click === 'function') {
        el.wrappedJSObject.click();
        clicked = true;
      }
    } catch (e) {}

    if (!clicked) {
      try {
        el.click();
        clicked = true;
      } catch (e) {
        try {
          el.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true, composed: true, view: window, detail: 1, button: 0 }));
          clicked = true;
        } catch (e2) {}
      }
    }

    return clicked;
  }

  /**
   * Smoothly scrolls all scrollable containers (window, document, and inner MUI/feed wrappers)
   */
  function scrollAllScrollableContainers() {
    // 1. Window scroll
    try {
      window.scrollBy(0, 1500);
      window.dispatchEvent(new Event('scroll'));
    } catch (e) {}

    // 2. Document elements
    try {
      if (document.documentElement) {
        document.documentElement.scrollTop += 1500;
      }
      if (document.body) {
        document.body.scrollTop += 1500;
      }
      if (document.scrollingElement) {
        document.scrollingElement.scrollTop += 1500;
        document.scrollingElement.dispatchEvent(new Event('scroll', { bubbles: true }));
      }
    } catch (e) {}

    // 3. Structural feed candidates (main, feed, timeline, MuiContainer, role="feed", etc.)
    try {
      const candidates = document.querySelectorAll(
        'main, #content, #learningJourneyRoot, [role="main"], [role="feed"], [class*="feed"], [class*="timeline"], [class*="stream"], [class*="MuiContainer"], [class*="scroll"], section, [class*="sc-"], [class*="css-"]'
      );
      for (let i = 0; i < candidates.length; i++) {
        const el = candidates[i];
        if (el.scrollHeight > el.clientHeight + 25) {
          el.scrollTop += 1500;
          if (typeof el.scrollBy === 'function') {
            el.scrollBy(0, 1500);
          }
          el.dispatchEvent(new Event('scroll', { bubbles: true }));
        }
      }
    } catch (e) {}

    // 4. Virtual list wheel event
    try {
      window.dispatchEvent(new WheelEvent('wheel', { deltaY: 1500, bubbles: true }));
    } catch (e) {}
  }

  /**
   * Detects the feed pagination "Load More" / "Load Earlier" button
   * Ignores inline comment truncation buttons ("Show more" inside .story) and header/tab dropdowns ("More" with arrow_drop_down)
   */
  function findLoadMoreElement() {
    const candidates = Array.from(document.querySelectorAll(
      'button, [role="button"], a, input[type="button"], input[type="submit"], [class*="MuiButton"], [class*="load-more"]'
    ));

    function isPaginationCandidate(el) {
      if (!el) return false;
      if (el.closest && el.closest('#famly-downloader-panel')) return false;
      if (el.disabled || el.getAttribute('aria-disabled') === 'true' || el.hasAttribute('disabled')) return false;
      // Ignore buttons inside individual story/post cards (e.g. inline comment "Show more" or "More options" menu)
      if (el.closest && el.closest('.story, article, .child-profile-header, .profile-header-wrapper, header, nav')) return false;
      // Ignore dropdown menu triggers containing Material icon text like "arrow_drop_down" or "more_horiz"
      const rawText = (el.textContent || '').toLowerCase();
      if (rawText.includes('arrow_drop_down') || rawText.includes('more_horiz') || rawText.includes('more_vert')) return false;
      return true;
    }

    // Priority 1: Exact pagination button labels ("load more", "load earlier", "load older", "hent mere")
    const primaryKeywords = [
      'load more', 'load earlier', 'load older', 'load previous',
      'see earlier', 'view earlier', 'hent mere', 'more posts', 'more photos'
    ];

    for (let i = 0; i < candidates.length; i++) {
      const el = candidates[i];
      if (!isPaginationCandidate(el)) continue;

      const text = (el.textContent || '').trim().toLowerCase();
      const aria = (el.getAttribute('aria-label') || '').toLowerCase();
      const testId = (el.getAttribute('data-testid') || '').toLowerCase();

      for (let k = 0; k < primaryKeywords.length; k++) {
        const kw = primaryKeywords[k];
        if (text === kw || text.includes(kw) || aria.includes(kw) || testId.includes(kw)) {
          return el;
        }
      }
    }

    // Priority 2: Secondary pagination phrases outside story cards ("show more", "show earlier", "view more", "older", "earlier", "ældre")
    const secondaryKeywords = ['show more', 'show earlier', 'view more', 'older', 'earlier', 'ældre'];
    for (let i = 0; i < candidates.length; i++) {
      const el = candidates[i];
      if (!isPaginationCandidate(el)) continue;

      const text = (el.textContent || '').trim().toLowerCase();
      if (text.length > 0 && text.length < 30) {
        for (let k = 0; k < secondaryKeywords.length; k++) {
          const kw = secondaryKeywords[k];
          if (text === kw || text.includes(kw)) {
            return el;
          }
        }
      }
    }

    return null;
  }

  /**
   * Executes a single robust scroll and click step across Firefox and Chrome
   */
  function performScrollStep() {
    scanCycles++;
    let clickedButton = false;

    // 1. Perform smooth scroll on all scrollable containers (window + inner feed containers)
    scrollAllScrollableContainers();

    // 2. Scroll last visible card / media into view to trigger virtual list / intersection observer
    try {
      const allCards = document.querySelectorAll(
        '.story, article, [role="article"], [class*="card"], [class*="post"], [class*="feed-item"], [class*="activity"], [class*="MuiCard"], img[src*="familyapp"], img[src*="archive"], video'
      );
      if (allCards.length > 0) {
        const lastEl = allCards[allCards.length - 1];
        lastEl.scrollIntoView({ behavior: 'auto', block: 'end' });
      }
    } catch (e) {}

    // 3. Find and trigger the "Load more" button once at the bottom of the feed
    const loadMoreBtn = findLoadMoreElement();
    if (loadMoreBtn) {
      clickedButton = triggerClick(loadMoreBtn);
    }

    // 4. Harvest newly rendered media
    harvestMedia();

    // 6. Update UI labels
    const scrollBtn = document.getElementById('famly-scroll-btn');
    if (scrollBtn && autoScrollInterval) {
      scrollBtn.textContent = clickedButton
        ? 'Loading More (' + scanCycles + ')...'
        : 'Auto-Scrolling (' + scanCycles + ')...';
    }
  }

  /**
   * Toggles auto-scroll loop
   */
  function toggleAutoLoad(customBtn) {
    const btn = customBtn || document.getElementById('famly-scroll-btn');
    if (autoScrollInterval) {
      clearInterval(autoScrollInterval);
      autoScrollInterval = null;
      scanCycles = 0;
      if (btn) {
        btn.textContent = 'Auto-Load Feed';
        btn.classList.remove('active');
      }
    } else {
      scanCycles = 0;
      if (btn) {
        btn.textContent = 'Stop Auto-Load';
        btn.classList.add('active');
      }
      // Execute immediately on click
      performScrollStep();
      // Repeat every 1400ms
      autoScrollInterval = setInterval(performScrollStep, 1400);
    }
    return Boolean(autoScrollInterval);
  }

  /**
   * Helper: Creates DOM elements safely via document.createElement (Firefox AMO compliant)
   */
  function createEl(tag, attrs, children) {
    const el = document.createElement(tag);
    if (attrs) {
      for (const k of Object.keys(attrs)) {
        if (k === 'className') el.className = attrs[k];
        else if (k === 'textContent') el.textContent = attrs[k];
        else el.setAttribute(k, attrs[k]);
      }
    }
    if (Array.isArray(children)) {
      for (let i = 0; i < children.length; i++) {
        if (children[i]) el.appendChild(children[i]);
      }
    }
    return el;
  }

  /**
   * Creates floating panel UI in page using safe DOM node construction
   */
  function createUI() {
    if (document.getElementById('famly-downloader-panel')) return;

    const panel = createEl('div', { id: 'famly-downloader-panel' });

    // Brand Icon badge (uses packaged icon32.png if available, with fallback glyph)
    let brandIconNode;
    try {
      const iconUrl = chrome.runtime.getURL('icons/icon32.png');
      brandIconNode = createEl('img', {
        src: iconUrl,
        alt: 'Nursery Media Downloader',
        className: 'famly-icon-img',
        width: '20',
        height: '20'
      });
    } catch (e) {
      brandIconNode = createEl('span', { className: 'famly-icon', textContent: '📷' });
    }

    const brandWrap = createEl('div', { className: 'famly-brand' }, [
      brandIconNode,
      createEl('span', { className: 'famly-title', textContent: 'Nursery Media Downloader' })
    ]);

    const minBtn = createEl('button', {
      id: 'famly-min-btn',
      title: 'Minimize / Expand',
      type: 'button',
      textContent: '_'
    });

    const header = createEl('div', { className: 'famly-header' }, [brandWrap, minBtn]);

    const queuedChip = createEl('div', { className: 'famly-stat-chip' }, [
      createEl('span', { className: 'famly-stat-num', id: 'famly-count-queued', textContent: '0' }),
      createEl('span', { className: 'famly-stat-label', textContent: 'Discovered' })
    ]);

    const savedChip = createEl('div', { className: 'famly-stat-chip' }, [
      createEl('span', { className: 'famly-stat-num', id: 'famly-count-saved', textContent: '0' }),
      createEl('span', { className: 'famly-stat-label', textContent: 'Saved' })
    ]);

    const statsRow = createEl('div', { className: 'famly-stats-row' }, [queuedChip, savedChip]);

    const scrollBtn = createEl('button', {
      id: 'famly-scroll-btn',
      className: 'famly-btn secondary',
      type: 'button',
      textContent: 'Auto-Load Feed'
    });

    const dlBtn = createEl('button', {
      id: 'famly-dl-btn',
      className: 'famly-btn primary',
      type: 'button',
      textContent: 'Download (0)'
    });

    const actionsRow = createEl('div', { className: 'famly-actions' }, [scrollBtn, dlBtn]);

    const copyBtn = createEl('button', {
      id: 'famly-copy-btn',
      className: 'famly-text-link',
      type: 'button',
      textContent: 'Copy URLs'
    });

    const optBtn = createEl('button', {
      id: 'famly-options-btn',
      className: 'famly-text-link',
      type: 'button',
      textContent: 'Folder & Settings'
    });

    const footerBar = createEl('div', { className: 'famly-footer-bar' }, [
      copyBtn,
      createEl('span', { className: 'famly-dot', textContent: '•' }),
      optBtn
    ]);

    const body = createEl('div', { className: 'famly-body' }, [
      statsRow,
      actionsRow,
      footerBar
    ]);

    panel.appendChild(header);
    panel.appendChild(body);
    document.body.appendChild(panel);

    // Event Listeners
    scrollBtn.addEventListener('click', () => toggleAutoLoad(scrollBtn));
    dlBtn.addEventListener('click', () => startDownload());

    optBtn.addEventListener('click', () => {
      chrome.runtime.sendMessage({ action: 'OPEN_OPTIONS' });
    });

    minBtn.addEventListener('click', () => {
      isPanelMinimized = !isPanelMinimized;
      panel.classList.toggle('minimized', isPanelMinimized);
      minBtn.textContent = isPanelMinimized ? '□' : '_';
    });

    copyBtn.addEventListener('click', () => {
      const urls = Array.from(mediaQueue.values()).map((v) => v.url).join('\\n');
      navigator.clipboard.writeText(urls);
      copyBtn.textContent = 'Copied!';
      setTimeout(() => { copyBtn.textContent = 'Copy URLs'; }, 1500);
    });

    updateUI();
  }

  /**
   * Only updates UI when counts or download state actually change
   */
  function updateUI() {
    if (
      lastQueuedCount === mediaQueue.size &&
      lastSavedCount === downloadedUrls.size &&
      lastDownloadingState === isDownloading
    ) {
      return;
    }
    lastQueuedCount = mediaQueue.size;
    lastSavedCount = downloadedUrls.size;
    lastDownloadingState = isDownloading;

    const queueEl = document.getElementById('famly-count-queued');
    const savedEl = document.getElementById('famly-count-saved');
    const dlBtn = document.getElementById('famly-dl-btn');

    if (queueEl) queueEl.textContent = String(mediaQueue.size);
    if (savedEl) savedEl.textContent = String(downloadedUrls.size);
    if (dlBtn) {
      dlBtn.disabled = isDownloading || mediaQueue.size === 0;
      dlBtn.textContent = isDownloading ? 'Downloading...' : 'Download (' + mediaQueue.size + ')';
    }
  }

  /**
   * Lightweight debounced MutationObserver
   */
  function initObserver() {
    try {
      const observer = new MutationObserver((mutations) => {
        let relevant = false;
        for (let i = 0; i < mutations.length; i++) {
          const m = mutations[i];
          if (m.type === 'attributes') {
            relevant = true;
            break;
          }
          if (m.type === 'childList') {
            const added = m.addedNodes;
            for (let j = 0; j < added.length; j++) {
              const n = added[j];
              if (n.nodeType === 1) { // ELEMENT_NODE
                if (n.tagName === 'IMG' || n.tagName === 'VIDEO' || n.tagName === 'SOURCE') {
                  relevant = true;
                  break;
                }
                if (n.querySelector && n.querySelector('img, video, [style*="url("]')) {
                  relevant = true;
                  break;
                }
              }
            }
            if (relevant) break;
          }
        }
        if (relevant) {
          scheduleHarvest(400);
        }
      });

      observer.observe(document.body || document.documentElement, {
        childList: true,
        subtree: true,
        attributes: true,
        attributeFilter: ['src', 'srcset', 'data-src', 'data-srcset', 'style']
      });
    } catch (e) {}
  }

  // Listen for messages from background and popup
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.action === 'TOGGLE_AUTO_LOAD') {
      const active = toggleAutoLoad();
      sendResponse({ isAutoLoading: active });
      return true;
    } else if (msg.action === 'DOWNLOAD_ITEMS') {
      startDownload();
      sendResponse({ status: 'initiated' });
      return true;
    } else if (msg.action === 'DOWNLOAD_PROGRESS') {
      const { completed, failed, total, currentUrl } = msg.progress;
      downloadedUrls.add(getMediaKey(currentUrl));
      chrome.storage.local.set({ downloadedHistory: Array.from(downloadedUrls) });
      updateUI();
    } else if (msg.action === 'DOWNLOAD_COMPLETE') {
      isDownloading = false;
      updateUI();
    } else if (msg.action === 'GET_CONTENT_STATS') {
      // Perform quick harvest to ensure current state before responding
      harvestMedia();
      sendResponse({
        queueCount: mediaQueue.size,
        savedCount: downloadedUrls.size,
        isDownloading: isDownloading,
        isAutoLoading: Boolean(autoScrollInterval),
        items: Array.from(mediaQueue.values())
      });
      return true;
    }
  });

  // Initialization - runs once on page load without high-frequency polling
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
      createUI();
      initObserver();
      harvestMedia();
    });
  } else {
    createUI();
    initObserver();
    harvestMedia();
  }
})();
