// Options page logic
document.addEventListener('DOMContentLoaded', () => {
  const folderInput = document.getElementById('downloadFolder');
  const promptSaveAs = document.getElementById('promptSaveAs');
  const patternInput = document.getElementById('namingPattern');
  const saveBtn = document.getElementById('saveBtn');
  const savedToast = document.getElementById('savedToast');

  // Load saved settings
  chrome.storage.sync.get({
    downloadFolder: 'Nursery_Photos',
    namingPattern: '{date}_media_{index}',
    promptSaveAs: false
  }, (items) => {
    folderInput.value = items.downloadFolder || 'Nursery_Photos';
    patternInput.value = items.namingPattern || '{date}_media_{index}';
    promptSaveAs.checked = Boolean(items.promptSaveAs);
  });

  saveBtn.addEventListener('click', () => {
    chrome.storage.sync.set({
      downloadFolder: folderInput.value.trim() || 'Nursery_Photos',
      namingPattern: patternInput.value.trim() || '{date}_media_{index}',
      promptSaveAs: promptSaveAs.checked
    }, () => {
      savedToast.style.display = 'inline';
      setTimeout(() => {
        savedToast.style.display = 'none';
      }, 2000);
    });
  });
});
