// Popup logic
document.addEventListener('DOMContentLoaded', async () => {
  const statusEl = document.getElementById('tab-status');
  const queueEl = document.getElementById('queue-count');
  const savedEl = document.getElementById('saved-count');
  const dlBtn = document.getElementById('download-btn');
  const autoBtn = document.getElementById('auto-scroll-btn');
  const optBtn = document.getElementById('options-btn');
  const openOptionsLink = document.getElementById('open-options');

  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  const isFamlyTab = tab?.url && (
    tab.url.includes('brighthorizons') ||
    tab.url.includes('famly')
  );

  if (isFamlyTab) {
    statusEl.textContent = 'Feed Active';
    statusEl.className = 'badge active';
  }

  // Query stats from content script (works even if tab.url is restricted)
  if (tab?.id) {
    chrome.tabs.sendMessage(tab.id, { action: 'GET_CONTENT_STATS' }, (res) => {
      if (!chrome.runtime.lastError && res) {
        statusEl.textContent = 'Feed Active';
        statusEl.className = 'badge active';
        queueEl.textContent = res.queueCount || 0;
        savedEl.textContent = res.savedCount || 0;
        if (res.isAutoLoading) {
          autoBtn.textContent = 'Stop Auto-Scroll';
          autoBtn.classList.add('active');
        } else {
          autoBtn.textContent = 'Auto-Load Feed';
          autoBtn.classList.remove('active');
        }
        if (res.queueCount > 0 && !res.isDownloading) {
          dlBtn.disabled = false;
          dlBtn.textContent = 'Download ' + res.queueCount + ' Items';
        }
      } else if (!isFamlyTab) {
        statusEl.textContent = 'Not on Portal';
        statusEl.className = 'badge inactive';
        dlBtn.textContent = 'Open Famly / FamilyApp First';
        dlBtn.disabled = true;
      }
    });
  } else {
    statusEl.textContent = 'Not on Portal';
    statusEl.className = 'badge inactive';
    dlBtn.textContent = 'Open Famly / FamilyApp First';
    dlBtn.disabled = true;
  }

  dlBtn.addEventListener('click', () => {
    if (!tab?.id) return;
    chrome.tabs.sendMessage(tab.id, { action: 'DOWNLOAD_ITEMS' });
    window.close();
  });

  autoBtn.addEventListener('click', () => {
    if (!tab?.id) return;
    chrome.tabs.sendMessage(tab.id, { action: 'TOGGLE_AUTO_LOAD' }, (res) => {
      if (res && res.isAutoLoading) {
        autoBtn.textContent = 'Stop Auto-Scroll';
        autoBtn.classList.add('active');
      } else {
        autoBtn.textContent = 'Auto-Load Feed';
        autoBtn.classList.remove('active');
      }
    });
  });

  if (optBtn) {
    optBtn.addEventListener('click', () => {
      chrome.runtime.openOptionsPage();
    });
  }

  if (openOptionsLink) {
    openOptionsLink.addEventListener('click', (e) => {
      e.preventDefault();
      chrome.runtime.openOptionsPage();
    });
  }
});
